import numpy as np

from cs231n.layers import *
from cs231n.fast_layers import *
from cs231n.layer_utils import *


class ThreeLayerConvNet(object):
  """
  A three-layer convolutional network with the following architecture:
  
  conv - relu - 2x2 max pool - affine - relu - affine - softmax
  
  The network operates on minibatches of data that have shape (N, C, H, W)
  consisting of N images, each with height H and width W and with C input
  channels.
  """
  
  def __init__(self, input_dim=(3, 32, 32), num_filters=32, filter_size=7,
               hidden_dim=100, num_classes=10, weight_scale=1e-3, reg=0.0,
               dtype=np.float32):
    """
    Initialize a new network.
    
    Inputs:
    - input_dim: Tuple (C, H, W) giving size of input data
    - num_filters: Number of filters to use in the convolutional layer
    - filter_size: Size of filters to use in the convolutional layer
    - hidden_dim: Number of units to use in the fully-connected hidden layer
    - num_classes: Number of scores to produce from the final affine layer.
    - weight_scale: Scalar giving standard deviation for random initialization
      of weights.
    - reg: Scalar giving L2 regularization strength
    - dtype: numpy datatype to use for computation.
    """
    self.params = {}
    self.reg = reg
    self.dtype = dtype
    print('CNN INIT')
    
    ############################################################################
    # TODO: Initialize weights and biases for the three-layer convolutional    #
    # network. Weights should be initialized from a Gaussian with standard     #
    # deviation equal to weight_scale; biases should be initialized to zero.   #
    # All weights and biases should be stored in the dictionary self.params.   #
    # Store weights and biases for the convolutional layer using the keys 'W1' #
    # and 'b1'; use keys 'W2' and 'b2' for the weights and biases of the       #
    # hidden affine layer, and keys 'W3' and 'b3' for the weights and biases   #
    # of the output affine layer.                                              #
    ############################################################################
    pass
	
    W1 = np.random.normal(0,weight_scale,num_filters*filter_size*filter_size*3)
    W1 = np.reshape(W1, [num_filters,3,filter_size,filter_size])
    b1 = np.zeros([num_filters,1])
    W2 = np.random.normal(0,weight_scale,int(input_dim[1]/2)*int(input_dim[1]/2)*num_filters*hidden_dim)
    W2 = np.reshape(W2, [int(input_dim[1]/2)*int(input_dim[1]/2)*num_filters,hidden_dim])
    b2 = np.zeros([hidden_dim])
    W3 = np.random.normal(0,weight_scale,hidden_dim*num_classes)
    W3 = np.reshape(W3, [hidden_dim,num_classes])
    b3 = np.zeros([num_classes])	
	
    self.params = {'W1': W1, 'b1': b1, 'W2': W2, 'b2': b2, 'W3': W3, 'b3': b3}
    ############################################################################
    #                             END OF YOUR CODE                             #
    ############################################################################

    for k, v in self.params.items():
      self.params[k] = v.astype(dtype)		
     
	
  def loss(self, X, y=None):
    """
    Evaluate loss and gradient for the three-layer convolutional network.
    
    Input / output: Same API as TwoLayerNet in fc_net.py.
    """
    W1, b1 = self.params['W1'], self.params['b1']
    W2, b2 = self.params['W2'], self.params['b2']
    W3, b3 = self.params['W3'], self.params['b3']
	
    #print('W1 shape = ', self.params['W1'].shape)
    
    # pass conv_param to the forward pass for the convolutional layer
    filter_size = W1.shape[2]
    conv_param = {'stride': 1, 'pad': (filter_size - 1) / 2}

    # pass pool_param to the forward pass for the max-pooling layer
    pool_param = {'pool_height': 2, 'pool_width': 2, 'stride': 2}

    scores = None
    ############################################################################
    # TODO: Implement the forward pass for the three-layer convolutional net,  #
    # computing the class scores for X and storing them in the scores          #
    # variable.                                                                #
    ############################################################################
    pass
	
	
	  #conv - relu - 2x2 max pool - affine - relu - affine - softmax
	  
    #print("FORWARD ==================")
    CONV_OUT, _ = conv_forward_naive(X, self.params['W1'], self.params['b1'], conv_param)
    #print('CONV_OUT shape = ', CONV_OUT.shape)
	
    #print("FORWARD ==================")
    RELU1_OUT, _ = relu_forward(CONV_OUT)
    #print('RELU1_OUT shape = ', RELU1_OUT.shape)
	
    #print("FORWARD ==================")
    MAX_OUT, _ = max_pool_forward_naive(RELU1_OUT, pool_param)
    #print('MAX_OUT shape = ', MAX_OUT.shape)
	
    #print("FORWARD ==================")
    FC1_OUT, _ = affine_forward(MAX_OUT, self.params['W2'], self.params['b2'])
    #print('FC1_OUT shape = ', FC1_OUT.shape)
	
    #print("FORWARD ==================")
    RELU2_OUT, _ = relu_forward(FC1_OUT)
    #print('RELU2_OUT shape = ', RELU2_OUT.shape)
	
    #print("FORWARD ==================")
    FC2_OUT, _ = affine_forward(RELU2_OUT, self.params['W3'], self.params['b3'])
    #print('FC2_OUT shape = ', FC2_OUT.shape)
	
    scores = FC2_OUT
	
    ############################################################################
    #                             END OF YOUR CODE                             #
    ############################################################################
    
    if y is None:
      return scores
    
    loss, grads = 0, {}
    ############################################################################
    # TODO: Implement the backward pass for the three-layer convolutional net, #
    # storing the loss and gradients in the loss and grads variables. Compute  #
    # data loss using softmax, and make sure that grads[k] holds the gradients #
    # for self.params[k]. Don't forget to add L2 regularization!               #
    ############################################################################
    pass
	
    #print("BACKPROP ==================")
    _, cache = affine_forward(RELU2_OUT, self.params['W3'], self.params['b3'])
    dX_FC2, dW3, db3 = affine_backward(FC2_OUT, cache)
    #print('dX_FC2 shape = ', dX_FC2.shape)
    #print('dW3 shape = ', dW3.shape)
    #print('db3 shape = ', db3.shape)
	
    #print("BACKPROP ==================")
    _, cache = relu_forward(FC1_OUT)
    dX_RELU2 = relu_backward(RELU2_OUT, cache)
    #print('dX_RELU2 shape = ', dX_RELU2.shape)
	
    #print("BACKPROP ==================")
    _, cache = affine_forward(MAX_OUT, self.params['W2'], self.params['b2'])
    dX_FC1, dW2, db2 = affine_backward(FC1_OUT, cache)
    #print('dX_FC1 shape = ', dX_FC1.shape)
    #print('dW2 shape = ', dW2.shape)
    #print('db2 shape = ', db2.shape)
	
   #print("BACKPROP ==================")
    _, cache = max_pool_forward_naive(RELU1_OUT, pool_param)
    dX_MAX = max_pool_backward_naive(MAX_OUT, cache)
    #print('dX_MAX shape = ', dX_MAX.shape)
	
    #print("BACKPROP ==================")
    _, cache = relu_forward(CONV_OUT)
    dX_RELU1 = relu_backward(RELU1_OUT, cache)
    #print('dX_RELU1 shape = ', dX_RELU1.shape)
	
    #print("BACKPROP ==================")
    _, cache = conv_forward_naive(X, self.params['W1'], self.params['b1'], conv_param)
    dX_CONV, dW1, db1 = conv_backward_naive(CONV_OUT,cache)
    #print('dX_CONV shape = ', dX_CONV.shape)
	
    grads = {'W1': dW1, 'b1': db1, 'W2': dW2, 'b2': db2, 'W3': dW3, 'b3': db3}
	
    #print("SOFTMAX ==================")
	#print('Y = ', y)
    #print('Y shape = ', y.shape)
	
    softmax_input = scores; 
    #print('softmax_input shape is = ', softmax_input.shape)	
	
    softmax_input_trans = np.transpose(softmax_input)
    #print('softmax_input_trans shape = ', softmax_input_trans.shape)
	
    #print('softmax input scores = ', softmax_input_trans)
	
    max_input = np.amax(softmax_input_trans, axis = 0)
    #print('max input shape = ', max_input.shape)
    #print('max input = ', max_input)
	
    max_vector = np.repeat(max_input, softmax_input_trans.shape[0], axis = 0)
    max_matrix = np.reshape(max_vector ,(softmax_input_trans.shape[1], softmax_input_trans.shape[0]))
    max_matrix = np.transpose(max_matrix)
    #print('max_matrix shape =', max_matrix.shape)
    #print('max_matrix = ', max_matrix)
	
    normalized_input = softmax_input_trans - max_matrix #- softmax_input_trans
    #print('normalized input = ', normalized_input)
	
    exp_scores = np.exp(normalized_input)
    #print('exp of scores = ', exp_scores)
	
    sum_exp_scores = np.sum(exp_scores, axis = 0)
    #print('sum of exp scores = ', sum_exp_scores)
	
	
    P = np.empty([softmax_input_trans.shape[0], softmax_input_trans.shape[1]])
    Py = np.empty([y.shape[0]])
    for i in range(y.shape[0]): 
         P[:,i] = exp_scores[:,i] / sum_exp_scores[i]
    
    #print("Probabilities = ", P)
    for i in range(y.shape[0]): 
         Py[i] = P[y[i],i]  
    #print('Py = ', Py)	
	
    data_loss = -1*np.log(Py)
    #print('data loss = ', data_loss)
    #print('reg = ', self.reg)
	
    avg_data_loss =  (1/softmax_input_trans.shape[1]) * np.sum(data_loss)
   # print('average data loss = ', avg_data_loss)
	
    reg_loss = (self.reg*np.sum(self.params['W2'] **2) + self.reg*np.sum(self.params['W1'] **2)  + self.reg*np.sum(self.params['W3'] **2)) /2
    #print('regularization loss = ', reg_loss)
	
    loss = avg_data_loss + reg_loss
	
    #print('loss = ', loss)
	
	
	
    ############################################################################
    #                             END OF YOUR CODE                             #
    ############################################################################
    
    return loss, grads
  
  
pass
